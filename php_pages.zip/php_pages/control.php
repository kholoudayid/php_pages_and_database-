<!DOCTYPE html1>
<html>
<head>
<meta charset="utf-8">
<title> Control Panel</title>
<style>
body{
background-image:url(z.png);
background-attachment: fixed;
font-family:arial;
}
h1{

  margin-top:5%;
  margin-left:5%;
}
p{
  margin-top:3%;
  margin-left:5%;
}
.c{
  color:#9a0e35;
}
ul{
  position: absolute;
  left: 85%;
  top:40%;
  transform: translate(-40%,-40%);
  list-style: none;
}
li img{
  width:50%;
  height: 10%;
  margin:2%;
  padding: 2%;

}
li{
  margin-bottom: 50px;
  position: relative;

}
ul li:nth-child(odd)
{
  left:-110px;
}
ul li:nth-child(even)
{
  left:50px;
}
ul:before{
  position: absolute;
  content: "";
  width: 10px;
  height:100%;
  background:#000;
  margin: 1em;
}
ul li:after{
  position: absolute;
  content: "";
  width: 30px;
  height:30px;
  background-color:#000;
  border-radius: 50%;
  top:50%;
  transform: translate(-40%,-40%);

}
ul li:nth-child(even):after
{
  left:-30px;
}
ul li:nth-child(odd):after
{
  left:125px;
}
li button {
position: absolute;
margin-left: -45%;
margin-top:55%;
background-color: #CDC8D1;
border:3px solid #CDC8D1;
box-shadow: 0 20px 20px #000;
}

</style>
</head>
<body>
  <div>
  <h1> CONTROL PANEL </h1>
  <p> I wnat to Move Please <span class="c"> HELP ME ! </span> </p>
</div>
  <div>
  <ul>
    <li>
      <div>
        <form action="up.php" method="post">
        <img src="up.png">
        <button name="button" value="iup"> Move up</button>
      </form>
      </div>
    </li>
    <li>
      <div>
        <form action="left.php" method="post">
        <img src="left.png">
        <button name="button" value="ileft"> Move left</button>
      </form>
      </div>
    </li>
    <li>
      <div>
        <form action="stop.php" method="post">
        <img src="stop.png">
        <button name="button" value="istop"> Stop</button>
      </form>
      </div>
    </li>

    <li>
      <div>
        <form action="down.php" method="post">
        <img src="down.png" >
        <button name="button" value="idown"> Move down</button>
      </form>

      </div>
    </li>
    <li>
      <div>
        <form action="right.php" method="post">
        <img src="right.png">
        <button name="button" value="iright"> Move right</button>
      </form>
      </div>
    </li>
  </ul>
</div>
</body>
</html>
