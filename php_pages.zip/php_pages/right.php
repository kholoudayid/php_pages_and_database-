<!DOCTYPE html1>
<html>
<head>
<meta charset="utf-8">
<title> Control Panel</title>
<style>
body{
background-image:url(z.png);
background-attachment: fixed;
font-family:arial;
}
</style>
</head>
<body>
<?php

$dbServer="localhost";
$dbuser="kholoud";
$dbPassword="kholoud123";
$dbName="remote_control";


$conn=mysqli_connect($dbServer,$dbuser,$dbPassword,$dbName);
$button=$_POST['button'];
 if ($button=='iright') {
   $sql = "INSERT INTO remote (iup ,idown , ileft , iright , istop  )
   VALUES (0,0,0,1,0)";

   if ($conn->query($sql) === TRUE) {
     echo "<h1> Right </h1>";
   } else {
     echo "Error: " . $sql . "<br>" . $conn->error;
   }
 }


?>
</body>
</html>
